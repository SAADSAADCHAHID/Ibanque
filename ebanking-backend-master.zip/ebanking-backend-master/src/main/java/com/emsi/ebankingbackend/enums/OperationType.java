package com.emsi.ebankingbackend.enums;

public enum OperationType {
    DEBIT,CREDIT
}
